package tp_tictactoe_1769692;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author <b><i>Moudio Kwakep Kevin Nelson</i></b>
 * DA: 1769692
 * Date de remise: 09-03-2018
 * Version 3.0
 * Copyright    All right reserved
 * Jeu Tic Tac Toe contre l'ordinateur
 * Prof: Mme Amal 
 */
public class TP_TicTacToe_1769692 {
    // Noms des constantes déclarées dans le programme

    protected static final int VIDE = 0;//space
    protected static final int ZERO = 111;
    protected static final int CROIX = 120;
    private static final int UTILISATEUR = 1;//User
    private static final int ORDINATEUR = 2;//AI
    private static final int INITJEU = 3;/**
     * Nombre de case minimum pour pouvoir jouer au Tic Tac Toe
     */
    private static final String BYE = "Aurevoir!";
    private static final String ALLO = "Bonjour!";
    private static final String YES = "oui";
    private static final String Y = "o";
    public static final String CONDITION_NAME = "^[a-zA-Z]*$";
    protected static final String NAME_USER = "Donnez votre nom: ";
    protected static final String INPUT_DIMENSION = "Donnez la dimension de "
            + "votre grille de jeu: ";
    
    public static int joueur;
    @SuppressWarnings("FieldMayBeFinal")
    private static Scanner x = new Scanner(System.in);
    public static Random ran = new Random();// random AI position
    public static Random coordAI = new Random();
    public static Scanner coordUser = new Scanner(System.in);
    public static char caractereOrdi = 'o';//Caractère de l'AI
    public static char caractereUser = 'x';// Caratère de l'utilisateur
    public static Scanner rejouer = new Scanner(System.in); /**
     * Rejouer une nouvelle partie
     */
  
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        jouer();//Racine du jeu
    }

    /**
     *Cette méthode remplace <b>la méthode main</b>, qui d'habitude nous 
     * Permettais de lancer l'exécution de nos programmes.
     * Elle permet de lancer et de gérer le jeu.
     * Elle contient toute les méthodes qui seront utiles pour 
     * la bonne exécution du code.
     */
    private static void jouer() {
        System.out.println(ALLO);
        String nomJoueur = infosJoueur();//Demande du nom du joueur
        do {
            int dimension = 0;
            messageBienvenue(nomJoueur);//Message de bienvenue
            dimension = creerTableau(dimension);
            char[][] grille = new char[dimension][dimension];//création tableau
            afficherTableau(grille);//Premier affichage de la grille de Jeu
            choixPremier();//choix du joueur qui commence 
            do {
                obtenirCoordUtilisateur(grille);

                boolean gagne = verifierGagnant(grille);
                changerJoueur(gagne);//Altenance des joueurs
                if (gagne) {
                    if (joueur == UTILISATEUR) {
                        reinitialiserGrilleDeJeu(grille);/**
                         * Permet de remettre des espaces dans les cases de la
                         * grille de jeu.
                         */
                        break;
                    } else if (joueur == ORDINATEUR) {
                        reinitialiserGrilleDeJeu(grille);/**
                         * Permet de remettre des espaces dans les cases de la
                         * grille de jeu.
                         */
                        break;
                    }
                    if (!gagne) {
                        System.out.println("C'est un match nul!\n"
                    + "Voulez-vous rejour:");
                    }
                }

            } while (verifierMatchNul(grille));/**
             * Permet au code de s'exécuter tant qu'une des cases de la grille
             * de jeu est vide.
             */
        } while (gagnant());/**
         * Affiche le message correspondant au gagnant et demande
         * à l'utilisateur s'il veut refaire une partie.
         */
    }
/**
 * Cette méthode permet d'afficher le gagnant d'une partie.
 * Elle permet également de demander à l'utilisateur s'il veut rejouer
 * ou non. Elle <b>retourne True</b>
 * @return boolean
 */
    private static boolean gagnant() {
        String reload = "";
        if (joueur == ORDINATEUR) {
            System.out.println("Game Over!! Vous avez perdu et c'est "
                    + "l'IA qui a gagné!"
                    + "(lol)\nVoulez-vous rejour: ");
            reload = rejouer.nextLine();
        } else if (joueur == UTILISATEUR) {
            System.out.println("Bravo!\n"
                    + "Vous avez gagné :)\n"
                    + "Voulez-vous rejour: ");
            reload = rejouer.nextLine();
        }
        else{
            System.out.println("C'est un match nul!\n"
                    + "Voulez-vous rejour:");
            reload = rejouer.nextLine();
        }
        if (reload.equalsIgnoreCase(YES) || reload.equalsIgnoreCase(Y)) {
            return true;
        } else {
            System.out.println(BYE);
            System.exit(0);
            return false;
        }

    }

    /**
     * Cette méthode premet de demander à l'utilisateur son nom et envoie cette 
     * variable à la méthode <b>messageBienvenue</b> qui en fait un
     * affichage en fonction du contenu de la variable.
     * <u>Elle n'accepte que des lettres<u> 
     * <b>sans caractères spéciaux</b>,<i>ni espaces</i>.
     * @return nom
     */
    private static String infosJoueur() {
        boolean continuer = false;
        String nom;
        do {
            System.out.print(NAME_USER);
            nom = x.nextLine();
            if (nom.matches(CONDITION_NAME)) {/**
             * Le nom entré doit absolument être une chaine de caractère,
             * ne doit contenir aucun espace, <b>aucun chiffre</b>, ni aucun <b>
             * caractère spécial.</b>
             */
                continuer = true;
            } else {
                System.out.println("Vous avez saisi n'importe quoi, \n"
                        + "Veuillez recommencer s'il vous plaît.");
            }

        } while (!continuer);
        return nom;
    }

    /**
     * Cette méthode permet de demnader à l'utilisateur la taille de la grille
     * de jeu à afficher. Elle prends en paramètre un entier <b>(int)</b>
     * qui représente la taille du tableau définis dans la <i>méthode jouer.</i>
     *
     * @param n
     * @return n
     */
    private static int creerTableau(int n) {
        Scanner r = new Scanner(System.in);
        boolean verification = false;
        System.out.print(INPUT_DIMENSION);
        do {
            try {
                do {
                    n = r.nextInt();
                    if (n < INITJEU) {
                        System.out.print("Vous devez entrer un nombre supérieur"
                                + "à 2\n"
                                + "Veuillez réessayer: ");
                    }
                } while (n < INITJEU);
                verification = true;
            } catch (InputMismatchException e) {
                System.out.print("Vous devez entrer un chiffre, "
                        + "réessayez svp: ");
                r.nextLine();
            }
        } while (!verification && n <= INITJEU);
        return n;
    }

    /**
     *Permet simplement d'afficher le message de bienvenue en fonction du nom 
     * entré par l'utilisateur.
     * @param nomJoueur
     */
    private static void messageBienvenue(String nomJoueur) {
        System.out.println("Bienvenue, " + nomJoueur
                + "! Êtes-vous prêt(e) à jouer ? ");
    }

    /**
     * Cette méthode prends en paramètre la carte du jeu et en fait un affichage
     * selon certains critères: Les cases sont séparées par des tirets et les
     * bordures sont délimités par des <b><i>+-</i></b>
     * De plus, quelque soit taille de la carte à afficher, les bordures doivent
     * commencer par un <b>+</b> et se terminer par un autre <b>+</b>.
     *
     * @param grille
     */
    private static void afficherTableau(char[][] grille) {
        @SuppressWarnings("UnusedAssignment")
        int j;

        for (int i = 0, len = grille.length; i < len; i++) {

            if (i == 0) {
//                System.out.print("\n");
                for (int l = 0; l <= len; l++) {
                    if (l == grille.length) {
                        System.out.print("+");
                    } else {
                        System.out.print("+ - ");
                    }
                }
                System.out.println();
            }
            if (grille[i][0] == 0) {
                System.out.print("|");
            } else {
                System.out.print("|");
            }
            for (j = 0, len = grille.length; j < len; j++) {
                remplissageEspaces(grille[i][j]);
                System.out.print("|");

            }

            System.out.print("\n");
            for (int k = 0; k <= len; k++) {
                if (k == grille.length) {
                    System.out.print("+");
                } else {
                    System.out.print("+ - ");
                }
            }
            System.out.println();
        }
    }

    /**
     * Cette méthode permet de mettre des espaces dans le tableau afin d'avoir
     * un affichage plus beau.
     *Les variables <b>o</b> et <b>x</b> ici présentent devaient initialement
     * servir de <u>constante</u> pour les caractères à jouer.
     * Elles par la suite permises d'afficher la grille du jeu.
     * @param c
     */
    private static void remplissageEspaces(char c) {
        switch (c) {
            case VIDE:
                System.out.print("   ");
                break;
            case ZERO:
                System.out.print(" o ");
                break;
            case CROIX:
                System.out.print(" x ");
                break;
        }
    }

    /**
     * Cette méthode permet de déterminer le joueur qui commence la partie. Elle
     * prends en paramètre une variable globale <b>(joueur)</b>, qui est
     * comparée à deux entiers <b>(1 et 2)</b>
     */
    private static void choixPremier() {
        joueur = ran.nextInt(15);
        System.out.print("Résultat du tirage est: ");
        if (joueur < 7) {
            System.out.println("L'utilisateur est le premier");
            System.out.print("Entrez vos coordonnées svp: ");
            joueur = UTILISATEUR;
        } else {
            System.out.println("l'IA est le premier joueur. ");
            System.out.println("L'IA a choisi sa cellule: ");
            joueur = ORDINATEUR;
        }
    }
/**
 * Cette méthode permet d'obtenir les coordonnées de l'utilisateur et 
 * de mettre une case de manière aléatoire dans la grille lorsque l'AI ne peut
 * pas contrer l'utilisateur.
 * Elle gère également une exception qui permet de boucler tant que
 * l'utilisateur ne rentre pas des entiers.
 * @param grille 
 * @exception InputMismatchException
 */
    private static void obtenirCoordUtilisateur(char[][] grille) {
        int x = 0; //coordonnée 1 à afficher
        int y = 0; //coordonnée 2 à afficher
        char caractereOrdi = 'o'; // caractère de l'AI
        char caractereUser = 'x'; // Caratère de l'utilisateur
        boolean trouve = false;// vérifie si les coordonnées entrés sont justes
        if (joueur == ORDINATEUR) {
            x = coordAI.nextInt(grille.length);//position 1 AI
            y = coordAI.nextInt(grille.length);//position 2 AI
//             verifierMouvement(grille);
        } else if (joueur == UTILISATEUR) {
            do {
                try {
                    x = coordUser.nextInt();//position 1 User
                    y = coordUser.nextInt();//position 2 User
                    if (x >= 0 && y >= 0) {
                        if (x <= grille.length && y <= grille.length) {
                            trouve = true;//Permet de sortir de la boucle
                        }
                        else{
                        System.out.println("Vous avez depasser les bornes du "
                            + "tableau\nVeuillez réessayer svp: ");
                        }
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Vous devez entrer un chiffre, "
                            + "veuillez réessayer s'il vous plait. ");
                    System.out.println("Entrez vos coordonnées: ");
                    coordUser.nextLine();//Pour vider le scanner 
                } 

            } while (!trouve);
        }

        remplirTalbeau(grille, x, y, caractereOrdi, caractereUser);
    }
/**
 * La méthode remplir prends en paramètre la grille, les coordonnées à 
 * écrire et le caractère du joueur dont la manche est en cours.
 * Elle vérifie que la case demandée est vide et écris le caractère 
 * correspondant dans la case en question si elle est vide, sinon elle renvoi
 * vers la la methode obtenirCoord qui redemande les données.
 * @param grille
 * @param x
 * @param y
 * @param caractereOrdi
 * @param caractereUser 
 */
    private static void remplirTalbeau(char[][] grille, int x,
            int y, char caractereOrdi, char caractereUser) {
        if (joueur == ORDINATEUR) {
            if (grille[x][y] != VIDE) {
                obtenirCoordUtilisateur(grille);
            } else {
                grille[x][y] = caractereOrdi; //Ecriture du caractère de l'AI
                afficherTableau(grille);
            }
        } else {

            if (x > grille.length - 1 && y > grille.length - 1) {
                System.out.print("Erreur, rentrez de nouvelles "
                        + "coordonnées: ");
                obtenirCoordUtilisateur(grille);

            } else if (grille[x][y] != VIDE) {
                System.out.println("La case est déjà occupée, \nEntrez de "
                        + "nouvelles coordonées svp: ");
                obtenirCoordUtilisateur(grille);
            } else {
                grille[x][y] = caractereUser; //Ecriture du caractère du User
                afficherTableau(grille);
            }
        }

    }

    /**
     * Cette méthode permet de changer de joueur après chaque fin de tour. Elle
     * prends en paramètre la variable <b>globale <i>joueur</i></b> qui sert de
     * <b>variable tampon</b> à l'utilisateur et à l'Intelligence Artificielle
     */
    private static void changerJoueur(boolean val) {
        if (joueur == ORDINATEUR && !val) {
            System.out.println("Entrez vos coordonnées, SVP: ");
            joueur = UTILISATEUR;
        } else if(joueur == UTILISATEUR && !val){
            joueur = ORDINATEUR;
            System.out.println("L'AI a choisi sa cellule: ");
        }

    }
/**
 * Elle permet de vérifier que toutes les cases sont remplies.
 * Le code ne s'arretera pas tant qu'il y aura des cases vides ou qu'il n y aura 
 * pas de vainqueur.
 * @param grille
 * @return boolean
 */
    private static boolean verifierMatchNul(char[][] grille) {
        for (int i = 0; i < grille.length; i++) {
            for (int j = 0; j < grille[i].length; j++) {

                if (grille[i][j] == VIDE) {
                    return true;
                }
            }

        }
        return false;
    }
/**
 * Cette méthode permet de vérifier si l'un des deux joueurs gagne ou non
 * la partie.
 * Elle retourne <b>True</b> si elle trouve un gagnat et <b>false</b> 
 * si elle n'en trouve aucun
 * Elle appelle la méthode <b><i>chercherGagnant</i></b> qui permet de parcourir
 * la grille de jeu à la recherche d'<b>une ligne</b>, d'<b>une colonne</b> ou 
 * d'<b>une diagonale</b> gagnante.
 * @param grille
 * @return boolean
 */
    private static boolean verifierGagnant(char[][] grille) {
        for (int i = 0; i < grille.length; i++) {
            for (int j = 0; j < grille.length; j++) {
                if ((chercherGagnant(grille, i, j, -1, 1) == grille.length)) {
                    return true;

                } else if //horizontalement, allant vers la droite.
                        (chercherGagnant(grille, i, j, 0, 1) == grille.length) {
                    return true;

                } else if //en diagonale vers le bas et la droite.
                        (chercherGagnant(grille, i, j, 1, 1) == grille.length) {
                    return true;

                } else if //verticalement vers le bas.
                        (chercherGagnant(grille, i, j, 1, 0) == grille.length) {
                    return true;
                }
            }
        }
        return false;
    }
/**
 * Elle permet de chercher une colonne, une ligne horizontale ou verticale 
 * gagnante
 * @param tab
 * @param ligneDepart
 * @param colonneDepart
 * @param dirLigne
 * @param dirColonne
 * @return Compteur
 */
    private static int chercherGagnant(char[][] tab, int ligneDepart, int colonneDepart,
            int dirLigne, int dirColonne) {
        int compteur = 0;
        int ligne = ligneDepart;
        int colonne = colonneDepart;
        while (ligne < tab.length && colonne < tab.length && ligne >= 0
                && colonne >= 0
                && tab[ligne][colonne] == tab[ligneDepart][colonneDepart]
                && tab[ligneDepart][colonneDepart] != VIDE) {
            compteur++;
            ligne = ligne + dirLigne;
            colonne = colonne + dirColonne;
        }
        return compteur;

    }
/**
 * Permet de remettre la grille du jeu à <i>0</i> au cas où l'utilisateur 
 * voudrait refaire une partie.
 * @param grille 
 */
    private static void reinitialiserGrilleDeJeu(char[][] grille) {
        for (int i = 0; i < grille.length; i++) {
            for (int j = 0; j < grille[i].length; j++) {
                grille[i][j] = VIDE;

            }
        }
    }

    private static void verifierMouvement(char[][] grille) {
        for (int i = 0; i < grille.length; i++) {
            for (int j = 0; j < grille[i].length; j++) {
                if (i ==j) {
                    if ((grille.length-1 == 'x' || grille[0][0]=='x') 
                            && grille[i][j] == VIDE) {
                        grille[i][j] = 'o';
                    }
                }
                    
//                else if () {
//                    
//                }
                
            }
            
        }
}

}
